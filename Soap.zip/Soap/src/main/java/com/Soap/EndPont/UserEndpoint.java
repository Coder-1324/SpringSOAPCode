package com.Soap.EndPont;

import org.springframework.beans.factory.annotation.Autowired;

import com.Soap.service.UserService;

@Endpoint
public class UserEndpoint<GetUserResponse, GetUserRequest> {
    private static final String NAMESPACE_URI = "http://example.com/user";

    @Autowired
    private UserService userService;

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getUserRequest")
    @ResponsePayload
    public GetUserResponse getUser(@RequestPayload GetUserRequest request) {
        GetUserResponse response = new GetUserResponse();
        response.setUser(userService.getUser(request.getId()));
        return response;
    }
}
