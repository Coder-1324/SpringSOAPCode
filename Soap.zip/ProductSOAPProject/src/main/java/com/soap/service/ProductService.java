package com.soap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.soap.product.ProductRepository;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;
    // methods for CRUD operations
}