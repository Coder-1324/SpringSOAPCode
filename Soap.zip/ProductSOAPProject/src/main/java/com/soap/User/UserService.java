package com.soap.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.soap.User.UserRepository;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    // methods for CRUD operations
}