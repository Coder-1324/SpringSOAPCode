package com.devtool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDevToolApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDevToolApplication.class, args);
	}

}
