package com.devtool;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class TestController {
	
	@RequestMapping("/test")
	@ResponseBody
	public String test() {
		
		int a =25;
		int b = 8;
		return "This is for testing /t sum of and b is " +(a*b);
	}

	
}
